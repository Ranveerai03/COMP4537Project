const MESSAGES = {
    loginFailed: 'Login failed. Please check your email and password.',
    registrationFailed: 'Registration failed. Please try again.',
    registrationSuccess: 'Registration successful! Redirecting to login...'
};